package parcautomobile;

import java.util.Scanner;

public class MenuConsole {
    private static ParcAutomobile parcAutomobile = new ParcAutomobile();
    private static Scanner scanner = new Scanner(System.in);

    public static void afficherMenu() {
        System.out.println("1. Ajouter un nouveau véhicule");
        System.out.println("2. Ajouter un nouveau client");
        System.out.println("3. Louer un véhicule");
        System.out.println("4. Retourner un véhicule");
        System.out.println("5. Lister les véhicules disponibles");
        System.out.println("6. Quitter");
    }

    public static void main(String[] args) {
        int choix;
        do {
            afficherMenu();
            choix = scanner.nextInt();
            scanner.nextLine(); // Pour gérer la nouvelle ligne après l'entrée

            switch (choix) {
                case 1:
                    // Code pour ajouter un nouveau véhicule
                    break;
                case 2:
                    // Code pour ajouter un nouveau client
                    break;
                case 3:
                    // Code pour louer un véhicule
                    break;
                case 4:
                    // Code pour retourner un véhicule
                    break;
                case 5:
                    // Code pour lister les véhicules disponibles
                    break;
                case 6:
                    System.out.println("Au revoir!");
                    break;
                default:
                    System.out.println("Choix invalide, réessayez.");
            }
        } while (choix != 6);
    }

    private static class ParcAutomobile {
    }
}

