package parcautomobile;

import java.util.ArrayList;

public class Client {
    private String nom;
    private String prenom;
    private String numeroPermis;
    private String telephone;
    private ArrayList<Vehicule> locationsEnCours;

    public Client(String nom, String prenom, String numeroPermis, String telephone) {
        this.nom = nom;
        this.prenom = prenom;
        this.numeroPermis = numeroPermis;
        this.telephone = telephone;
        this.locationsEnCours = new ArrayList<>();
    }

    public void ajouterLocation(Vehicule vehicule) {
        locationsEnCours.add(vehicule);
    }

    public void retirerLocation(Vehicule vehicule) {
        locationsEnCours.remove(vehicule);
    }
}
