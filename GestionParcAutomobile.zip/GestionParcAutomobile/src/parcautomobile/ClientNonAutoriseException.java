package parcautomobile;

public class ClientNonAutoriseException extends Exception {
    public ClientNonAutoriseException(String message) {
        super(message);
    }
}
