package parcautomobile;

import java.util.ArrayList;
import java.util.Scanner;

class Vehicule {
    private String immatriculation;
    private String marque;
    private String modèle;
    private int annéeMiseEnService;
    private double kilomètrage;
    private boolean estLoue; // false = disponible, true = loué

    public Vehicule(String immatriculation, String marque, String modèle, int annéeMiseEnService, double kilomètrage) {
        this.immatriculation = immatriculation;
        this.marque = marque;
        this.modèle = modèle;
        this.annéeMiseEnService = annéeMiseEnService;
        this.kilomètrage = kilomètrage;
        this.estLoue = false;
    }

    public boolean estDisponible() {
        return !estLoue;
    }

    public void louer() throws Exception {
        if (estLoue) throw new Exception("Le véhicule est déjà loué.");
        estLoue = true;
    }

    public void retourner() {
        estLoue = false;
    }

    public double calculerPrixLocation() {
        return 0; // Redéfinir dans les sous-classes
    }

    public String toString() {
        return marque + " " + modèle + " (" + immatriculation + "), " + (estLoue ? "loué" : "disponible");
    }
}

class Voiture extends Vehicule {
    private int nombrePlaces;
    private String typeCarburant;

    public Voiture(String immatriculation, String marque, String modèle, int annéeMiseEnService, double kilomètrage, int nombrePlaces, String typeCarburant) {
        super(immatriculation, marque, modèle, annéeMiseEnService, kilomètrage);
        this.nombrePlaces = nombrePlaces;
        this.typeCarburant = typeCarburant;
    }

    @Override
    public double calculerPrixLocation() {
        return 50.0; // Exemple : prix fixe pour une voiture
    }
}

class Camion extends Vehicule {
    private double capacitéChargement;
    private int nombreEssieux;

    public Camion(String immatriculation, String marque, String modèle, int annéeMiseEnService, double kilomètrage, double capacitéChargement, int nombreEssieux) {
        super(immatriculation, marque, modèle, annéeMiseEnService, kilomètrage);
        this.capacitéChargement = capacitéChargement;
        this.nombreEssieux = nombreEssieux;
    }

    @Override
    public double calculerPrixLocation() {
        return 100.0; // Exemple : prix fixe pour un camion
    }
}

class Client {
    private String nom;
    private String prénom;
    private String numeroPermis;
    private String numeroTélephone;
    private ArrayList<Vehicule> locationsEnCours;

    public Client(String nom, String prenom, String numeroPermis, String numeroTélephone) {
        this.nom = nom;
        this.prénom = prenom;
        this.numeroPermis = numeroPermis;
        this.numeroTélephone = numeroTélephone;
        this.locationsEnCours = new ArrayList<>();
    }

    public void ajouterLocation(Vehicule vehicule) {
        locationsEnCours.add(vehicule);
    }

    public void retournerVehicule(Vehicule vehicule) {
        locationsEnCours.remove(vehicule);
    }

    public String toString() {
        return nom + " " + prénom + ", permis: " + numeroPermis;
    }
}

class ParcAutomobile {
    private ArrayList<Vehicule> vehicules;
    private ArrayList<Client> clients;

    public ParcAutomobile() {
        vehicules = new ArrayList<>();
        clients = new ArrayList<>();
    }

    public void ajouterVehicule(Vehicule vehicule) {
        vehicules.add(vehicule);
    }

    public void ajouterClient(Client client) {
        clients.add(client);
    }

    public Vehicule trouverVehiculeDisponible(String immatriculation) {
        for (Vehicule v : vehicules) {
            if (v.estDisponible() && v.toString().contains(immatriculation)) {
                return v;
            }
        }
        return null;
    }

    public Client trouverClient(String numeroPermis) {
        for (Client c : clients) {
            if (c.toString().contains(numeroPermis)) {
                return c;
            }
        }
        return null;
    }

    public void louerVehicule(Client client, Vehicule vehicule) throws Exception {
        vehicule.louer();
        client.ajouterLocation(vehicule);
    }

    public void retournerVehicule(Client client, Vehicule vehicule) {
        vehicule.retourner();
        client.retournerVehicule(vehicule);
    }

    public void listerVehicules() {
        for (Vehicule v : vehicules) {
            System.out.println(v);
        }
    }

    public static void main(String[] args) {
        ParcAutomobile parc = new ParcAutomobile();
        Scanner scanner = new Scanner(System.in);

        boolean running = true;
        while (running) {
            System.out.println("1. Ajouter un véhicule");
            System.out.println("2. Ajouter un client");
            System.out.println("3. Louer un véhicule");
            System.out.println("4. Retourner un véhicule");
            System.out.println("5. Lister les véhicules");
            System.out.println("6. Quitter");
            System.out.print("Choix : ");
            int choix = scanner.nextInt();
            scanner.nextLine(); // Vider la ligne

            switch (choix) {
                case 1:
                    System.out.print("Type de véhicule (voiture/camion): ");
                    String type = scanner.nextLine();
                    System.out.print("Immatriculation: ");
                    String immatriculation = scanner.nextLine();
                    System.out.print("Marque: ");
                    String marque = scanner.nextLine();
                    System.out.print("Modèle: ");
                    String modele = scanner.nextLine();
                    System.out.print("Année de mise en service: ");
                    int annee = scanner.nextInt();
                    System.out.print("Kilométrage: ");
                    double kilometrage = scanner.nextDouble();

                    if (type.equalsIgnoreCase("voiture")) {
                        System.out.print("Nombre de places: ");
                        int places = scanner.nextInt();
                        System.out.print("Type de carburant: ");
                        scanner.nextLine();
                        String carburant = scanner.nextLine();
                        parc.ajouterVehicule(new Voiture(immatriculation, marque, modele, annee, kilometrage, places, carburant));
                    } else if (type.equalsIgnoreCase("camion")) {
                        System.out.print("Capacité de chargement: ");
                        double capacite = scanner.nextDouble();
                        System.out.print("Nombre d'essieux: ");
                        int essieux = scanner.nextInt();
                        parc.ajouterVehicule(new Camion(immatriculation, marque, modele, annee, kilometrage, capacite, essieux));
                    }
                    break;
                case 2:
                    System.out.print("Nom: ");
                    String nom = scanner.nextLine();
                    System.out.print("Prénom: ");
                    String prenom = scanner.nextLine();
                    System.out.print("Numéro de permis: ");
                    String permis = scanner.nextLine();
                    System.out.print("Numéro de téléphone: ");
                    String telephone = scanner.nextLine();
                    parc.ajouterClient(new Client(nom, prenom, permis, telephone));
                    break;
                case 3:
                    System.out.print("Numéro de permis du client: ");
                    String permisClient = scanner.nextLine();
                    Client client = parc.trouverClient(permisClient);
                    if (client != null) {
                        System.out.print("Immatriculation du véhicule: ");
                        String immatVehicule = scanner.nextLine();
                        Vehicule vehicule = parc.trouverVehiculeDisponible(immatVehicule);
                        if (vehicule != null) {
                            try {
                                parc.louerVehicule(client, vehicule);
                                System.out.println("Véhicule loué avec succès.");
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        } else {
                            System.out.println("Véhicule non disponible.");
                        }
                    } else {
                        System.out.println("Client non trouvé.");
                    }
                    break;
                case 4:
                    System.out.print("Numéro de permis du client: ");
                    permisClient = scanner.nextLine();
                    client = parc.trouverClient(permisClient);
                    if (client != null) {
                        System.out.print("Immatriculation du véhicule: ");
                        immatriculation = scanner.nextLine();
                        Vehicule vehicule = parc.trouverVehiculeDisponible(immatriculation);
                        if (vehicule != null) {
                            parc.retournerVehicule(client, vehicule);
                            System.out.println("Véhicule retourné avec succès.");
                        } else {
                            System.out.println("Véhicule non trouvé.");
                        }
                    } else {
                        System.out.println("Client non trouvé.");
                    }
                    break;
                case 5:
                    parc.listerVehicules();
                    break;
                case 6:
                    running = false;
                    break;
                default:
                    System.out.println("Choix invalide.");
            }
        }

        scanner.close();
    }
}

