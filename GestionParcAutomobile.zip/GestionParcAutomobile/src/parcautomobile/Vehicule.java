package parcautomobile;

public abstract class Vehicule {
    protected String immatriculation;
    protected String marque;
    protected String modele;
    protected int anneeService;
    protected int kilometrage;
    protected boolean estLoue;

    public Vehicule(String immatriculation, String marque, String modele, int anneeService, int kilometrage) {
        this.immatriculation = immatriculation;
        this.marque = marque;
        this.modele = modele;
        this.anneeService = anneeService;
        this.kilometrage = kilometrage;
        this.estLoue = false;
    }

    public abstract double calculerPrixLocation();

    public boolean isDisponible() {
        return !estLoue;
    }

    public void setEstLoue(boolean estLoue) {
        this.estLoue = estLoue;
    }
}
