package parcautomobile;

public class Camion extends Vehicule implements Louable {
    private double capaciteChargement;
    private int nombreEssieux;

    public Camion(String immatriculation, String marque, String modele, int anneeService, int kilometrage, double capaciteChargement, int nombreEssieux) {
        super(immatriculation, marque, modele, anneeService, kilometrage);
        this.capaciteChargement = capaciteChargement;
        this.nombreEssieux = nombreEssieux;
    }

    @Override
    public double calculerPrixLocation() {
        return 100.0;
    }

    @Override
    public void louer() throws VehiculeIndisponibleException {
        if (estLoue) throw new VehiculeIndisponibleException("Le véhicule est déjà loué.");
        estLoue = true;
    }

    @Override
    public void retourner() {
        estLoue = false;
    }
}
