package parcautomobile;

public class Voiture extends Vehicule implements Louable {
    private int nombrePlaces;
    private String typeCarburant;

    public Voiture(String immatriculation, String marque, String modele, int anneeService, int kilometrage, int nombrePlaces, String typeCarburant) {
        super(immatriculation, marque, modele, anneeService, kilometrage);
        this.nombrePlaces = nombrePlaces;
        this.typeCarburant = typeCarburant;
    }

    @Override
    public double calculerPrixLocation() {
        return 50.0;
    }

    @Override
    public void louer() throws VehiculeIndisponibleException {
        if (estLoue) throw new VehiculeIndisponibleException("Le véhicule est déjà loué.");
        estLoue = true;
    }

    @Override
    public void retourner() {
        estLoue = false;
    }
}
