Projet : Gestion de Parc Automobile
===================================

Description :
-------------
Cette application console permet à une entreprise de location de gérer son parc de véhicules, les clients, et les locations. Elle utilise les concepts de programmation orientée objet (POO) pour gérer différents types de véhicules et d'interactions, tels que l'héritage, le polymorphisme, l'encapsulation et la gestion des exceptions.


Fonctionnalités :
-----------------
- Gestion des véhicules** : Ajout de véhicules de types variés (Voiture, Camion) au parc.
- Gestion des clients** : Enregistrement et suivi des informations des clients.
- Location et retour des véhicules** : Permettre la location d’un véhicule à un client et gérer les retours.
- **Affichage des véhicules** : Lister les véhicules disponibles ou actuellement loués.
- **Gestion des exceptions** : Vérification des règles de location et des autorisations des clients.


Structure du projet :
---------------------
Le projet est organisé en plusieurs classes, chacune avec des responsabilités spécifiques :

1. **Vehicule** : Classe abstraite représentant un véhicule. Elle contient des attributs communs à tous les véhicules comme l'immatriculation, la marque, le modèle, etc.
2. **Voiture** et **Camion** : Sous-classes de `Vehicule`, elles ajoutent des attributs spécifiques et implémentent la méthode de calcul du prix de location.
3. **Client** : Représente un client avec ses informations personnelles et ses locations en cours.
4. **ParcAutomobile** : Classe principale pour gérer la collection de véhicules.
5. **Louable** : Interface définissant les méthodes `louer()` et `retourner()`.
6. **Exceptions personnalisées** : `VehiculeIndisponibleException` et `ClientNonAutoriseException` pour gérer les erreurs spécifiques aux processus de location.


Prérequis :
-----------
- Java 8 ou version supérieure
- IntelliJ IDEA (ou un autre environnement de développement Java)


Installation :
--------------
1. **Téléchargez le projet** : Téléchargez le fichier `.zip` du projet ou clonez le dépôt GitHub.
2. **Ouvrez dans IntelliJ IDEA** :
   - Lancez IntelliJ IDEA et ouvrez le dossier du projet.
3. **Exécutez le programme** :
   - Compilez le projet, puis exécutez la classe `MenuConsole` pour lancer l'interface console.


Utilisation :
-------------
Le programme affiche un menu console interactif avec les options suivantes :
1. **Ajouter un nouveau véhicule** : Ajoute un véhicule (Voiture ou Camion) au parc avec ses caractéristiques.
2. **Ajouter un nouveau client** : Enregistre un client avec son nom, prénom, numéro de permis et téléphone.
3. **Louer un véhicule** : Loue un véhicule disponible à un client.
4. **Retourner un véhicule** : Marque le véhicule comme retourné et disponible.
5. **Lister les véhicules disponibles** : Affiche tous les véhicules actuellement disponibles.
6. **Quitter** : Ferme le programme.


